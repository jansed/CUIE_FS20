package cuie;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/**
 * @author Dieter Holz
 */
class ProjectSetupTest {

    @Test
    void testJunitConfiguration() {
        //given

        //when

        //then

        assertTrue(true, "Mit diesem Test wird nur überprüft ob JUnit richtig ins Projekt integriert wurde");
    }
}
